ECIO ARM USB driver.
Matrix Multimedia Ltd. June 2008

Hardware: Matrix ECIO ARM USB Drivers.
For: Windows 2000, XP and Vista.


To install for Windows 2000, XP and Vista:
Run the ECIOARM_Driver_Installer.exe before plugging in your hardware and follow the instructions provided.