/*  EB031 ARM Board Test prog*/
/*  Matrix April 2006        */
/*  V1.0.0                   */

#include "Board.h"

int main(void)
{
	unsigned int i;
	
	/* Set all of PORTA as an output */
    AT91F_PIO_CfgOutput( AT91C_BASE_PIOA, PORTA ) ;
	/* Set all of PORTA as an output */
    AT91F_PIO_CfgOutput( AT91C_BASE_PIOA, PORTB ) ;
	/* Set all of PORTA as an output */
    AT91F_PIO_CfgOutput( AT91C_BASE_PIOA, PORTC ) ;
	/* Set all of PORTA as an output */
    AT91F_PIO_CfgOutput( AT91C_BASE_PIOA, PORTD ) ;
	/* Set all of PORTA as an output */
   // AT91F_PIO_CfgOutput( AT91C_BASE_PIOA, PORTE ) ;
   
   // Redo Pins B5 and D4 as inputs to avoid USB problems
	/* Set PORTB5 as an input  */
	AT91F_PIO_CfgInput( AT91C_BASE_PIOA, PORTB5 );
	/* Set PORTD4 as an input  */
	AT91F_PIO_CfgInput( AT91C_BASE_PIOA, PORTD4 );
	/* Disable pullups on PORTB */
	//AT91F_PIO_DisablePullups( AT91C_BASE_PIOA, PORTB5 );
	/* Disable pullups on PORTD */
	//AT91F_PIO_DisablePullups( AT91C_BASE_PIOA, PORTD4 );
   
   
   unsigned int count;
	const unsigned int patterns [2] = 
	/*      0           1           */
    //{ 0x55545555, 0xAAAA8AAA} ; // edited to not trigger D4 and B5
    //{ 0x55555555, 0xAAAAAAAA} ; 
	{(PORTA0 | PORTA2 | PORTA4 | PORTA6 |
	PORTB0 | PORTB2 | PORTB4 | PORTB6 |
	PORTC0 | PORTC2 | PORTC4 | PORTC6 |
	PORTD0 | PORTD2 | PORTD6) ,
	(PORTA1 | PORTA3 | PORTA5 | PORTA7 |
	PORTB1 | PORTB3 | PORTB7 |
	PORTC1 | PORTC3 | PORTC5 | PORTC7 |
	PORTD1 | PORTD3 | PORTD5 | PORTD7)} ;

	while ( 1 )
	{
		count = 0;
		
		while ( count < 3 )
		{
			/* Set PORTA high */
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, PORTA ) ;
			/* Set PORTB high */
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, PORTB ) ;
			/* Set PORTC high */
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, PORTC ) ;
			/* Set PORTD high */
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, PORTD ) ;
			/* Set PORTE high */
			//AT91F_PIO_SetOutput( AT91C_BASE_PIOA, PORTE ) ;
			for ( i = 0 ; i < 2000000 ; i = i + 1 ) ;
	
			/* Set PORTA low */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, PORTA );
			/* Set PORTB low */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, PORTB );
			/* Set PORTC low */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, PORTC );
			/* Set PORTD low */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, PORTD );
			/* Set PORTE low */
			//AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, PORTE );
			for ( i = 0 ; i < 2000000 ; i = i + 1 ) ;
			
			count = count + 1;
		}
		
		count = 0;
		
		while ( count < 3 )
		{
			/* Set PORTA high */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, patterns[1] );
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, patterns[0] ) ;
			for ( i = 0 ; i < 2000000 ; i = i + 1 ) ;
	
			/* Set PORTA low */
			AT91F_PIO_ClearOutput( AT91C_BASE_PIOA, patterns[0] );
			AT91F_PIO_SetOutput( AT91C_BASE_PIOA, patterns[1] ) ;
			for ( i = 0 ; i < 2000000 ; i = i + 1 ) ;
		
			count = count + 1;
		}
	
		
	}
}
